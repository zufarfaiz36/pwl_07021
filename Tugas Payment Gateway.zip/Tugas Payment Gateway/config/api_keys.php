<?php
return [
    'rajaongkir' => [
        'destination' => [
            'base_url' => 'https://rajaongkir.komerce.id/api/v1',
            'endpoint' => '/destination/domestic-destination',
            'key' => 'T23m3mRN1513d9f7abc0e257zgFVoW5X'
        ],
        'ongkir' => [
            'base_url' => 'https://api-sandbox.collaborator.komerce.id',
            'endpoint' => '/tariff/api/v1/calculate',
            'key' => 'iRbq1lI91513d9f7abc0e2577pfPcdeI'
        ]
    ],
    
    'midtrans' => [
        'server_key' => 'SB-Mid-server-BszJV9LyVFPlz6-I4tnGvbTX',
        'client_key' => 'SB-Mid-client-ZMqfrLEL5Y1JQi5o',
        'is_production' => false
    ]
];
