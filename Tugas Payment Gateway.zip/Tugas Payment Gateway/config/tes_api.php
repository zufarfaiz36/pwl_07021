<?php
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => "https://rajaongkir.komerce.id/api/v1/destination/domestic-destination?limit=5&offset=0",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        "key: 7d0wJ9B630b318753c246f5dS07NSDRG"
    ]
]);
$response = curl_exec($curl);
curl_close($curl);
echo $response;
