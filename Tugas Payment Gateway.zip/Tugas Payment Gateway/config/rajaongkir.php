<?php
// Konfigurasi API Key RajaOngkir
define("RAJAONGKIR_API_KEY","7d0wJ9B630b318753c246f5dS07NSDRG");
define("RAJAONGKIR_BASE_URL","https://api-sandbox.collaborator.komerce.id");
