<?php
session_start();

// Ambil data cart dari POST (form modal), jika ada
if (isset($_POST['cart_data'])) {
    $decodedCart = json_decode($_POST['cart_data'], true);
    if (is_array($decodedCart)) {
        $_SESSION['cart'] = $decodedCart;
    }
}

$cart = $_SESSION['cart'] ?? [];

$totalPrice = 0;
$totalWeight = 0;

foreach ($cart as $item) {
    $totalPrice += $item['price'];
    $totalWeight += $item['weight'] ?? 0;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Checkout</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <span class="navbar-brand mb-0 h1">Checkout</span>
  </div>
</nav>

<div class="container my-4">
  <h5 class="mb-3">Daftar Produk:</h5>
  <ul class="list-group">
    <?php if (empty($cart)): ?>
      <li class="list-group-item">Keranjang kosong</li>
    <?php else: ?>
      <?php foreach ($cart as $item): ?>
        <li class="list-group-item d-flex justify-content-between">
          <?= htmlspecialchars($item['name']) ?>
          <span>Rp<?= number_format($item['price']) ?></span>
        </li>
      <?php endforeach; ?>
    <?php endif; ?>
  </ul>

  <form method="post" action="bayar.php" class="mt-4">
    <input type="hidden" id="harga_produk" value="<?= $totalPrice ?>">
    <input type="hidden" id="ongkir_value" name="ongkir" value="0">
    <input type="hidden" id="total_final" name="total_final" value="<?= $totalPrice ?>">
    <input type="hidden" id="berat_total" value="<?= $totalWeight ?>">

    <div class="mb-3">
      <label class="form-label">Nama Lengkap</label>
      <input type="text" name="name" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Nomor HP</label>
      <input type="text" name="phone" class="form-control" required>
    </div>

    <div class="mb-3 position-relative">
      <label for="destination" class="form-label">Tujuan Pengiriman</label>
      <input type="text" id="destination" name="destination" class="form-control" placeholder="Masukkan kota/kecamatan..." required autocomplete="off">
      <input type="hidden" name="destination_id" id="destination_id">
      <div id="destination-list" class="list-group position-absolute z-3" style="width: 100%; max-height: 200px; overflow-y: auto; display: none;"></div>
    </div>

    <div class="mb-3">
      <label class="form-label">Alamat Lengkap</label>
      <textarea name="address" class="form-control" rows="3" required></textarea>
    </div>

   <div class="mb-3">
  <label class="form-label">Pilih Kurir:</label><br>
  <?php
    $couriers = ['NINJA', 'SICEPAT', 'SAP', 'JNE']; 
    foreach ($couriers as $courier) {
      echo '
        <div class="form-check form-check-inline">
          <input class="form-check-input" type="radio" name="courier" id="kurir'.$courier.'" value="'.$courier.'">
          <label class="form-check-label" for="kurir'.$courier.'">'.$courier.'</label>
        </div>';
    }
  ?>
</div>


    <style>
      .checkout-summary {
        background-color: #f9f9f9;
        padding: 24px;
        border-radius: 12px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        margin-top: 30px;
        max-width: 100%;
      }
      .summary-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
      }
      .summary-label {
        font-weight: bold;
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .summary-value {
        font-weight: bold;
        min-width: 100px;
        text-align: right;
      }
      .total-row {
        font-size: 20px;
        font-weight: bold;
        border-top: 1px solid #ccc;
        padding-top: 10px;
        margin-top: 15px;
      }
    </style>

    <div class="checkout-summary">
      <div class="summary-row">
        <div class="summary-label">📦 Total Berat:</div>
        <div class="summary-value"><?= $totalWeight ?> gram</div>
      </div>
      <div class="summary-row">
        <div class="summary-label">🚚 Ongkir:</div>
        <div class="summary-value" id="ongkir-display">Rp0</div>
      </div>
      <div class="summary-row total-row">
        <div class="summary-label">💳 Total:</div>
        <div class="summary-value" id="total_bayar">Rp<?= number_format($totalPrice, 0, ',', '.') ?></div>
      </div>
      <div class="text-end mt-3">
        <button type="button" class="btn btn-dark" id="pay-now">Bayar Sekarang</button>
      </div>
    </div>
  </form>
</div>

<script>
$(document).ready(function () {
  function hitungOngkir() {
    const destinationId = $('#destination_id').val();
    const courier = $('input[name="courier"]:checked').val();
    const totalProduk = parseInt($('#harga_produk').val());
    const totalBerat = parseInt($('#berat_total').val());

    if (!destinationId || !courier || !totalBerat) return;

    $.ajax({
      url: './get_ongkir.php',
      method: 'GET',
      data: {
        destination: destinationId,
        courier: courier,
        weight: totalBerat,
        item_value: totalProduk
      },
      success: function (res) {
        if (res.ongkir !== undefined && !res.error) {
          const ongkir = parseInt(res.ongkir);
          const totalBayar = totalProduk + ongkir;

          $('#ongkir-display').text('Rp' + ongkir.toLocaleString('id-ID'));
          $('#total_bayar').text('Rp' + totalBayar.toLocaleString('id-ID'));
          $('#ongkir_value').val(ongkir);
          $('#total_final').val(totalBayar);
        } else {
          alert('Kurir tidak ditemukan atau ongkir error.');
          $('#ongkir-display').text('Rp0');
          $('#total_bayar').text('Rp' + totalProduk.toLocaleString('id-ID'));
          $('#ongkir_value').val(0);
          $('#total_final').val(totalProduk);
        }
      },
      error: function () {
        alert('Gagal menghitung ongkir');
      }
    });
  }

  $('#destination').on('input', function () {
    let keyword = $(this).val().trim();

    if (keyword.length >= 3) {
      $.ajax({
        url: './get_destination.php',
        method: 'GET',
        data: { search: keyword },
        success: function (res) {
          if (res.data && res.data.length > 0) {
            let htmlList = '';
            res.data.forEach(function (item) {
              htmlList += `<button type="button" class="list-group-item list-group-item-action" data-id="${item.id}">${item.label}</button>`;
            });
            $('#destination-list').html(htmlList).show();
          } else {
            $('#destination-list').hide();
          }
        },
        error: function () {
          $('#destination-list').hide();
        }
      });
    } else {
      $('#destination-list').hide();
    }
  });

  $('#destination-list').on('click', '.list-group-item', function () {
    const selectedText = $(this).text();
    const selectedId = $(this).data('id');
    $('#destination').val(selectedText);
    $('#destination_id').val(selectedId);
    $('#destination-list').hide();
    hitungOngkir();
  });

  $('input[name="courier"]').on('change', function () {
    hitungOngkir();
  });

  $(document).on('click', function (e) {
    if (!$(e.target).closest('#destination, #destination-list').length) {
      $('#destination-list').hide();
    }
  });

  // Validasi kurir saat submit
  $('form').on('submit', function (e) {
    if (!$('input[name="courier"]:checked').val()) {
      alert('Silakan pilih kurir pengiriman terlebih dahulu.');
      e.preventDefault();
    }
  });
});
</script>


<!-- script untuk midtrans -->
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="SB-Mid-client-ZMqfrLEL5Y1JQi5o"></script>

<script>
  $('#pay-now').on('click', function () {
    const name = $('input[name="name"]').val();
    const phone = $('input[name="phone"]').val();
    const address = $('textarea[name="address"]').val();
    const destination = $('#destination').val();
    const total_final = $('#total_final').val();
    const ongkir = $('#ongkir_value').val();

    if (!name || !phone || !address || !destination) {
      alert("Harap lengkapi data pengiriman sebelum membayar.");
      return;
    }

    $.ajax({
      url: 'get_snap_token.php',
      method: 'POST',
      data: {
        name,
        phone,
        address,
        destination,
        total_final,
        ongkir
      },
      dataType: 'json',
      success: function(res) {
        if (res.token) {
          snap.pay(res.token, {
            onSuccess: function(result) {
              alert("Pembayaran berhasil!");
              console.log(result);
              window.location.href = 'index.php';
            },
            onPending: function(result) {
              alert("Menunggu pembayaran selesai.");
              console.log(result);
            },
            onError: function(result) {
              alert("Terjadi kesalahan saat pembayaran.");
              console.log(result);
            },
            onClose: function() {
              alert("Pembayaran dibatalkan.");
            }
          });
        } else {
          alert("Gagal mendapatkan token pembayaran.");
          console.log(res.error);
        }
      },
      error: function(err) {
        alert("Gagal mengirim data ke server.");
        console.log(err);
      }
    });
  });
</script>

</body>
</html>
