<?php
// Aktifkan tampilan error untuk debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Hitung jumlah item
$cartCount = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;

$products = [
  ["id" => 1, "name" => "Headset Sony", "price" => 2000000, "weight" => 1000, "image" => "image/produk1.jpg"],
  ["id" => 2, "name" => "Keyboard Wireless", "price" => 850000, "weight" => 800, "image" => "image/produk2.jpg"],
  ["id" => 3, "name" => "Mouse Logitech", "price" => 350000, "weight" => 400, "image" => "image/produk3.jpg"],
  ["id" => 4, "name" => "Smartwatch Xiaomi", "price" => 1200000, "weight" => 500, "image" => "image/produk4.jpg"],
  ["id" => 5, "name" => "Charger Anker", "price" => 299000, "weight" => 300, "image" => "image/produk5.jpg"],
  ["id" => 6, "name" => "Powerbank 10000mAh", "price" => 450000, "weight" => 1000, "image" => "image/produk6.jpg"],
  ["id" => 7, "name" => "Lampu LED USB", "price" => 50000, "weight" => 100, "image" => "image/produk7.PNG"],
  ["id" => 8, "name" => "Webcam HD", "price" => 750000, "weight" => 600, "image" => "image/produk8.PNG"],
  ["id" => 9, "name" => "Mini Speaker Bluetooth", "price" => 300000, "weight" => 700, "image" => "image/produk9.jpg"],
  ["id" => 10, "name" => "USB Hub 4 Port", "price" => 120000, "weight" => 250, "image" => "image/produk10.jpg"],

  

];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Beranda - Toko Online</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="#">GadgetID.</a>
    <button class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#cartModal">
      <i class="bi bi-cart-fill"></i>
      <span class="badge bg-danger rounded-pill" id="cart-count"><?= $cartCount ?></span>
    </button>
  </div>
</nav>

<div class="container my-5">
  <h1 class="mb-4 text-center fw-bold">Daftar Produk</h1>
  <div class="row row-cols-2 row-cols-md-4 g-4">
    <?php foreach ($products as $product): ?>
      <div class="col">
        <div class="card h-100">
          <img src="<?= $product['image'] ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>">
          <div class="card-body d-flex flex-column justify-content-between">
            <div>
              <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
              <p class="card-text">Rp<?= number_format($product['price'], 0, ',', '.') ?></p>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-outline-secondary add-to-cart"
                   data-id="<?= $product['id'] ?>"
                   data-name="<?= htmlspecialchars($product['name']) ?>"
                   data-price="<?= $product['price'] ?>"
                   data-weight="<?= $product['weight'] ?>">
                  <i class="bi bi-cart-plus"></i> Tambah
              </button>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<!-- Modal Keranjang -->
<div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="checkout.php" method="POST" onsubmit="return submitCart()">
        <input type="hidden" name="cart_data" id="cart_data">
        <div class="modal-header">
          <h5 class="modal-title" id="cartModalLabel">Keranjang Belanja</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
        </div>
        <div class="modal-body">
          <ul class="list-group" id="cart-items"></ul>
          <p class="mt-3"><strong>Total: Rp <span id="cart-total">0</span></strong></p>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success">Checkout</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const cart = JSON.parse(sessionStorage.getItem('cart')) || [];
const cartCountElem = document.getElementById('cart-count');

function updateCartDisplay() {
  const list = document.getElementById('cart-items');
  const totalElem = document.getElementById('cart-total');
  list.innerHTML = '';
  let total = 0;

  cart.forEach((item, index) => {
    const li = document.createElement('li');
    li.className = 'list-group-item d-flex justify-content-between align-items-center';
    li.innerHTML = `
      <div>${item.name} - Rp${item.price.toLocaleString('id-ID')}</div>
      <button class="btn btn-sm btn-danger btn-remove" data-index="${index}">Hapus</button>
    `;
    list.appendChild(li);
    total += item.price;
  });

  totalElem.textContent = total.toLocaleString('id-ID');
  cartCountElem.textContent = cart.length;

  // Tambahkan event listener untuk tombol hapus
  document.querySelectorAll('.btn-remove').forEach(button => {
    button.addEventListener('click', function () {
      const index = parseInt(this.dataset.index);
      cart.splice(index, 1);
      sessionStorage.setItem('cart', JSON.stringify(cart));
      updateCartDisplay();
    });
  });
}


updateCartDisplay();

function submitCart() {
  const cartInput = document.getElementById('cart_data');
  cartInput.value = JSON.stringify(cart);
  return true;
}

document.querySelectorAll('.add-to-cart').forEach(btn => {
  btn.addEventListener('click', function () {
    const id = parseInt(this.dataset.id);
    const name = this.dataset.name;
    const price = parseInt(this.dataset.price);
    const weight = parseInt(this.dataset.weight);
cart.push({ id, name, price, weight });

    sessionStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();

    fetch('add-to-cart.php', {
    method: 'POST',
    headers: {
    'Content-Type': 'application/json' },
    body: JSON.stringify({ id, name, price, weight })
  })
  .then(res => res.json())
  .then(data => {
  if (!data.success) {
    alert('Gagal menambahkan ke server: ' + (data.message || ''));
  }
})
  .catch(err => {
  console.error('Fetch error:', err);
});

  });
});
</script>
</body>
</html>
