<?php
require_once 'vendor/autoload.php';
use GuzzleHttp\Client;

header('Content-Type: application/json');

// Muat konfigurasi dari config/api_keys.php
$config = require __DIR__ . '/config/api_keys.php';

$mode = 'online';
$search = isset($_GET['search']) ? $_GET['search'] : '';

if ($mode === 'offline') {
    // Mode offline: ambil dari file dummy
    $data = json_decode(file_get_contents('dummy_destination.json'), true);
    $filtered = array_filter($data['data'], function($item) use ($search) {
        return stripos($item['label'], $search) !== false;
    });
    echo json_encode(['data' => array_values($filtered)]);
    exit;
}

// Mode online: ambil dari API RajaOngkir
try {
    $client = new Client();

    // Ambil konfigurasi dari file config
    $baseUrl = $config['rajaongkir']['destination']['base_url'];
    $endpoint = $config['rajaongkir']['destination']['endpoint'];
    $apiKey = $config['rajaongkir']['destination']['key'];

    $url = $baseUrl . $endpoint;

    $response = $client->request('GET', $url, [
        'headers' => [
            'accept' => 'application/json',
            'key' => $apiKey,
        ],
        'query' => [
            'search' => $search,
        ],
    ]);

    echo $response->getBody();
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
