<?php
session_start();

if (isset($_GET['json'])) {
    header('Content-Type: application/json');
    echo json_encode($_SESSION['cart'] ?? []);
    exit;
}

if (empty($_SESSION['cart'])) {
    echo '<li class="list-group-item text-center">Keranjang masih kosong.</li>';
} else {
    foreach ($_SESSION['cart'] as $index => $item) {
        $name = htmlspecialchars($item['name']);
        $price = htmlspecialchars($item['price']);
        echo "<li class='list-group-item d-flex justify-content-between align-items-center'>";
        echo "$name - <strong>$price</strong>";
        echo "<a href='hapus-cart.php?index=$index' class='btn btn-sm btn-danger'>Hapus</a>";
        echo "</li>";
    }
}
