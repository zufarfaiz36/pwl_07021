<?php
session_start();

// Header agar responnya selalu JSON
header('Content-Type: application/json');

// Ambil input JSON
$data = json_decode(file_get_contents("php://input"), true);

// Pastikan cart sudah diinisialisasi
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Validasi input
$id = $data['id'] ?? null;
$name = trim($data['name'] ?? '');
$price = $data['price'] ?? null;
$weight = $data['weight'] ?? null;

if (!empty($name) && is_numeric($price)) {
    $_SESSION['cart'][] = [
        'id' => $id
        'name' => $name,
        'price' => $price
        'weight' => $weight
    ];

    echo json_encode([
        'success' => true,
        'totalItems' => count($_SESSION['cart'])
    ]);
} else {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Nama, harga, atau berat tidak valid.'
    ]);
}
