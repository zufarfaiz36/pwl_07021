<?php
header('Content-Type: application/json');

require_once __DIR__ . '/vendor/autoload.php';
$config = require __DIR__ . '/config/api_keys.php';

// Konfigurasi mode
$useOnlineAPI = true;

// Validasi parameter
if (!isset($_GET['destination']) || !isset($_GET['courier']) || !isset($_GET['weight'])) {
    echo json_encode(['error' => 'Parameter tidak lengkap']);
    exit;
}

// Ambil parameter
$destinationId = (int) $_GET['destination'];
$courier = strtoupper(trim($_GET['courier']));
$weight = (int) $_GET['weight'];
$itemValue = isset($_GET['item_value']) ? (int) $_GET['item_value'] : 50000;
$shipperId = 31596;

// === Mode Offline ===
if (!$useOnlineAPI) {
    echo json_encode([
        'ongkir' => 15000,
        'source' => 'offline-mock',
        'courier' => $courier,
        'weight' => $weight
    ]);
    exit;
}

// === Ambil konfigurasi dari file ===
$baseUrl = $config['rajaongkir']['ongkir']['base_url'];
$endpoint = $config['rajaongkir']['ongkir']['endpoint'];
$apiKey = $config['rajaongkir']['ongkir']['key'];

$url = $baseUrl . $endpoint . '?' . http_build_query([
    'shipper_destination_id' => $shipperId,
    'receiver_destination_id' => $destinationId,
    'weight' => $weight,
    'item_value' => $itemValue,
    'cod' => 'no'
]);

// === Panggil API
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'x-api-key: ' . $apiKey
    ],
]);

$response = curl_exec($curl);
$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($httpCode !== 200 || !$response) {
    echo json_encode(['error' => 'Gagal mengambil ongkir dari API Komerce']);
    exit;
}

$data = json_decode($response, true);

// Untuk debugging (opsional)
file_put_contents(__DIR__ . '/log_ongkir.txt', print_r($data['data']['calculate_reguler'], true));

// === Ambil ongkir berdasarkan shipping_name ===
$selectedService = null;
if (isset($data['data']['calculate_reguler']) && is_array($data['data']['calculate_reguler'])) {
    foreach ($data['data']['calculate_reguler'] as $service) {
        if (strtoupper($service['shipping_name']) === $courier) {
            $selectedService = $service;
            break;
        }
    }
}

if (!$selectedService) {
    echo json_encode([
        'error' => true,
        'message' => 'Kurir tidak ditemukan dalam data ongkir',
        'courier_input' => $courier,
        'available_couriers' => array_map(function ($s) {
            return $s['shipping_name'];
        }, $data['data']['calculate_reguler'] ?? [])
    ]);
    exit;
}

// === Kirim hasil sukses ===
echo json_encode([
    'ongkir' => intval($selectedService['shipping_cost']) / 1000,
    'courier' => $courier,
    'service_name' => $selectedService['service_name'],
    'weight' => $weight,
    'source' => 'online-api'
]);
