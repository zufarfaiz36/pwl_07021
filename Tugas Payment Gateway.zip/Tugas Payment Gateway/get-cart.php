<?php
session_start();

if (isset($_GET['json'])) {
    header('Content-Type: application/json');
    echo json_encode($_SESSION['cart'] ?? []);
    exit;
}

if (empty($_SESSION['cart'])) {
    echo '<li class="list-group-item text-center">Keranjang masih kosong.</li>';
} else {
    foreach ($_SESSION['cart'] as $index => $item) {
        $name = htmlspecialchars($item['name']);
        $price = isset($item['price']) && is_numeric($item['price']) ? (float)$item['price'] : 0;

        echo "<li class='list-group-item d-flex justify-content-between align-items-center'>";
        echo "$name - <strong>Rp " . number_format($price, 0, ',', '.') . "</strong>";
        echo "<button class='btn btn-sm btn-danger btn-hapus ms-2' data-index='$index'>Hapus</button>";
        echo "</li>";
    }

    
}
