<?php
require_once __DIR__ . '/vendor/autoload.php';

use Midtrans\Config;
use Midtrans\Snap;

session_start();

// Ambil API Key dari config
$config = require __DIR__ . '/config/api_keys.php';
$midtransConfig = $config['midtrans'];

// Konfigurasi Midtrans
Config::$serverKey = $midtransConfig['server_key'];
Config::$isProduction = $midtransConfig['is_production'];
Config::$isSanitized = true;
Config::$is3ds = true;

$cart = $_SESSION['cart'] ?? [];

$name       = $_POST['name'] ?? 'Pembeli';
$phone      = $_POST['phone'] ?? '08123456789';
$address    = $_POST['address'] ?? '-';
$destination= $_POST['destination'] ?? '-';
$totalFinal = (int) ($_POST['total_final'] ?? 0);
$ongkir     = (int) ($_POST['ongkir'] ?? 0);

// Buat order ID unik
$order_id = 'ORDER-' . rand(10000, 99999) . '-' . time();

// Buat daftar item
$items = [];
foreach ($cart as $item) {
    $items[] = [
        'id' => $item['id'] ?? rand(1, 999),
        'price' => $item['price'],
        'quantity' => 1,
        'name' => $item['name']
    ];
}

// Tambah ongkir sebagai item
$items[] = [
    'id' => 'ONGKIR',
    'price' => $ongkir,
    'quantity' => 1,
    'name' => 'Ongkos Kirim'
];

// Payload transaksi
$transaction = [
    'transaction_details' => [
        'order_id' => $order_id,
        'gross_amount' => $totalFinal
    ],
    'item_details' => $items,
    'customer_details' => [
        'first_name' => $name,
        'phone' => $phone,
        'shipping_address' => [
            'address' => $address,
            'city' => $destination
        ]
    ]
];

// Kirim Snap Token
try {
    $snapToken = Snap::getSnapToken($transaction);
    echo json_encode(['token' => $snapToken]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
